package pl.reniferek.servertp;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ServerTeleport extends JavaPlugin implements Listener {
    private final Set<UUID> playersInside = new HashSet<>();

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ServerTeleport wlaczony!");
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        Location loc = player.getLocation();

        boolean inside =
                loc.getBlockX() >= -4 && loc.getBlockX() <= 4 &&
                loc.getBlockY() >= 68 && loc.getBlockY() <= 77 &&
                loc.getBlockZ() == 9;

        UUID uuid = player.getUniqueId();

        if (inside) {
            if (playersInside.add(uuid)) {
                player.performCommand("server LifeStealSMPspawn");
            }
        } else {
            playersInside.remove(uuid);
        }
    }
}
